# Partequipos: kit completo

Componentes de Partequipos para Next.js (App Router) + React + Tailwind CSS v4.

## Cómo usarlo

1. Copia `src/components/partequipos/` y `public/partequipos/` a tu proyecto
   con las mismas rutas (el código busca las imágenes en `/partequipos/...`).
2. Pega `estilos/partequipos.css` en tu CSS global, debajo de
   `@import "tailwindcss"`: trae los tokens de color (`bg-brand`,
   `text-on-bar`...) y las animaciones.
3. Instala las dependencias: `motion`.
4. Fuente: Inter (`next/font/google`) en el contenedor de la página.

## Secciones

- **Maquinaria pesada nueva**: Tarjetas de marca con foto, logo y presentación, y la retroexcavadora Case Utility Plus sobre la foto de obra.
  Uso: `<MaquinariaNueva />`
- **Maquinaria pesada usada**: Hero, filtro de 3 categorías y slider de equipos.
  Uso: `<CatalogoUsados hero={<UsedHero />} />`
- **Marcas**: Banda de logos en bucle con la retroexcavadora Case y su reflejo.
  Uso: `<MarcasSlider />`
- **Venta de repuestos**: 10 categorías con «Ver todos» y la Yanmar sobre piso cenital.
  Uso: `<CatalogoRepuestos />`
- **CTA de cotizar**: Banner oscuro con montañas, franjas rojas y el compactador Dynapac.
  Uso: `<BannerCotizar />`
- **Ficha de equipo**: Página de detalle de cada máquina, con galería y datos técnicos.
  Uso: `<ProductSheet equipo={getEquipo(slug)} />`
