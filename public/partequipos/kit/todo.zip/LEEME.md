# Partequipos: kit completo

Componentes de Partequipos para Next.js (App Router) + React + Tailwind CSS v4.

## Cómo usarlo

1. Copia `src/components/partequipos/` y `public/partequipos/` a tu proyecto
   con las mismas rutas (el código busca las imágenes en `/partequipos/...`).
2. Pega `estilos/partequipos.css` en tu CSS global, debajo de
   `@import "tailwindcss"`: trae los tokens de color (`bg-brand`,
   `text-on-bar`...) y las animaciones.
3. Instala las dependencias: `motion`.
4. Fuente: Inter (`next/font/google`) en el contenedor de la página.

## Secciones

- **Slider del home**: Cinco fotos a sangre con fundido y acercamiento lento, título en Anton con la excavadora cruzándolo, texto circular que gira, panel de vidrio, flechas, pausa y puntos con progreso. Necesita la fuente /partequipos/fuentes/Anton-Regular.woff2. Debajo, una barra con las 3 secciones principales (máquinas reales recortadas) y un fondo rojo que sigue al cursor.
  Uso: `<HeroSlider />`
- **Maquinaria pesada nueva**: Tarjetas de marca con foto, logo y presentación, y la retroexcavadora Case Utility Plus en un estudio con franjas grises y rojas, piso y reflejo.
  Uso: `<MaquinariaNueva />`
- **Maquinaria pesada usada**: Hero, filtro de 3 categorías y slider de equipos.
  Uso: `<CatalogoUsados hero={<UsedHero />} />`
- **Marcas**: Banda de logos en bucle con la retroexcavadora Case y su reflejo.
  Uso: `<MarcasSlider />`
- **Venta de repuestos**: Título, entrada con el enlace a WhatsApp y 10 categorías en tarjetas blancas con esquina roja, nombre y flecha.
  Uso: `<CatalogoRepuestos />`
- **Marcas de repuestos**: La Yanmar ViO80 a la izquierda y los logos de las marcas de repuestos corriendo detrás de ella.
  Uso: `<MarcasRepuestos />`
- **CTA de cotizar**: Banner oscuro con montañas, franjas rojas y el compactador Dynapac.
  Uso: `<BannerCotizar />`
- **Ficha de equipo**: Página de detalle de cada máquina, con galería y datos técnicos.
  Uso: `<ProductSheet equipo={getEquipo(slug)} />`
