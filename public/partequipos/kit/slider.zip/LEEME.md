# Partequipos: Slider del home

Componentes de Partequipos para Next.js (App Router) + React + Tailwind CSS v4.

## Cómo usarlo

1. Copia `src/components/partequipos/` y `public/partequipos/` a tu proyecto
   con las mismas rutas (el código busca las imágenes en `/partequipos/...`).
2. Pega `estilos/partequipos.css` en tu CSS global, debajo de
   `@import "tailwindcss"`: trae los tokens de color (`bg-brand`,
   `text-on-bar`...) y las animaciones.
3. Instala las dependencias: `motion`.
4. Fuente: Inter (`next/font/google`) en el contenedor de la página.

## Secciones

- **Slider del home**: Cinco fotos a sangre con fundido y acercamiento lento, título en Anton con la excavadora cruzándolo, texto circular que gira, panel de vidrio, flechas, pausa y puntos con progreso. Necesita la fuente /partequipos/fuentes/Anton-Regular.woff2. Debajo, una barra con las 3 secciones principales (máquinas reales recortadas) y un fondo rojo que sigue al cursor.
  Uso: `<HeroSlider />`
