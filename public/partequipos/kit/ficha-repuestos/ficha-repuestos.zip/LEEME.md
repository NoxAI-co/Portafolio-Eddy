# Partequipos: Ficha de repuestos de un modelo

Componentes de Partequipos para Next.js (App Router) + React + Tailwind CSS v4.

## Cómo usarlo

1. Copia `src/components/partequipos/` y `public/partequipos/` a tu proyecto
   con las mismas rutas (el código busca las imágenes en `/partequipos/...`).
2. Pega `estilos/partequipos.css` en tu CSS global, debajo de
   `@import "tailwindcss"`: trae los tokens de color (`bg-brand`,
   `text-on-bar`...) y las animaciones.
3. Instala las dependencias: ninguna extra.
4. Fuente: Inter (`next/font/google`) en el contenedor de la página.

## Secciones

- **Ficha de repuestos de un modelo**: Migas; cabecera con logo, separación, modelo, línea y botones de cotización y WhatsApp; categorías de repuestos en tarjetas con panel del tinte de la marca, foto, nombre y «Ver productos»; otros modelos con la franja de la marca. Datos de ejemplo en fichas.ts: CASE CX350B, Yanmar ViO80-1 y Hitachi ZX210-5G.
  Uso: `<FichaModeloRepuestos ficha={FICHA_CX350B} />`
