# Partequipos · Yanmar: Mascota de fondo

Componentes de Partequipos para Next.js (App Router) + React + Tailwind CSS v4.

## Cómo usarlo

1. Copia `src/components/partequipos/` y `public/partequipos/` a tu proyecto
   con las mismas rutas (el código busca las imágenes en `/partequipos/...`).
2. Pega `estilos/partequipos.css` en tu CSS global, debajo de
   `@import "tailwindcss"`: trae los tokens de color (`bg-brand`,
   `text-on-bar`...) y las animaciones.
3. Instala las dependencias: `motion`.
4. Fuente: Inter (`next/font/google`) en el contenedor de la página.

## Secciones

- **Mascota de fondo**: El sello de la marca grande y gris detrás de la página, que acompaña el scroll.
  Uso: `<AguilaFondo mascota={marca.mascota}>{contenido}</AguilaFondo>`
