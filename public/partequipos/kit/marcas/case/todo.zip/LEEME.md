# Partequipos · Case Construction: kit completo

Componentes de Partequipos para Next.js (App Router) + React + Tailwind CSS v4.

## Cómo usarlo

1. Copia `src/components/partequipos/` y `public/partequipos/` a tu proyecto
   con las mismas rutas (el código busca las imágenes en `/partequipos/...`).
2. Pega `estilos/partequipos.css` en tu CSS global, debajo de
   `@import "tailwindcss"`: trae los tokens de color (`bg-brand`,
   `text-on-bar`...) y las animaciones.
3. Instala las dependencias: `motion`.
4. Fuente: Inter (`next/font/google`) en el contenedor de la página.

## Secciones

- **Hero**: Banda partida con el color de la marca, foto, placa del logo, título e indicador de scroll.
  Uso: `<MarcaHero marca={marca} />`
- **Píldora de categorías**: Navegación de vidrio que aparece al bajar: logo y categorías, con la activa resaltada.
  Uso: `<PildoraMarca marca={marca} />`
- **Línea de equipos**: Texto de entrada y cinta continua con una tarjeta por tipo de máquina.
  Uso: `<LineaEquipos marca={marca} />`
- **Modelos por tipo**: Una sección por tipo: número, título, franja con la máquina, «Ver toda la categoría» y las tarjetas de cada modelo.
  Uso: `<ModelosMarca marca={marca} detalle />`
- **Ficha del modelo**: Página de cada modelo: foto grande, datos, cotizar y otros modelos del tipo. La foto de la tarjeta se transforma en la de la ficha con una transición de vista.
  Uso: `<FichaModelo marcaSlug="case" slug={params.modelo} />`
- **Mascota de fondo**: El sello de la marca grande y gris detrás de la página, que acompaña el scroll.
  Uso: `<AguilaFondo mascota={marca.mascota}>{contenido}</AguilaFondo>`
- **Landing completa**: La página entera de la marca armada con todas las secciones. Es el mismo zip que «Kit completo».
  Uso: `<LandingMarca marca={getMarca("case")!} />`
