# Partequipos · Dynapac: Ficha del modelo

Componentes de Partequipos para Next.js (App Router) + React + Tailwind CSS v4.

## Cómo usarlo

1. Copia `src/components/partequipos/` y `public/partequipos/` a tu proyecto
   con las mismas rutas (el código busca las imágenes en `/partequipos/...`).
2. Pega `estilos/partequipos.css` en tu CSS global, debajo de
   `@import "tailwindcss"`: trae los tokens de color (`bg-brand`,
   `text-on-bar`...) y las animaciones.
3. Instala las dependencias: `motion`.
4. Fuente: Inter (`next/font/google`) en el contenedor de la página.

## Secciones

- **Ficha del modelo**: Página de cada modelo: portada roja con logo y nombre, datos, cotizar y otros modelos del tipo. La portada de la tarjeta se transforma en la de la ficha con una transición de vista.
  Uso: `<FichaModelo marcaSlug="dynapac" slug={params.modelo} />`
