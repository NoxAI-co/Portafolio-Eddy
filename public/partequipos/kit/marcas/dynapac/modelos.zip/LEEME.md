# Partequipos · Dynapac: Modelos por tipo

Componentes de Partequipos para Next.js (App Router) + React + Tailwind CSS v4.

## Cómo usarlo

1. Copia `src/components/partequipos/` y `public/partequipos/` a tu proyecto
   con las mismas rutas (el código busca las imágenes en `/partequipos/...`).
2. Pega `estilos/partequipos.css` en tu CSS global, debajo de
   `@import "tailwindcss"`: trae los tokens de color (`bg-brand`,
   `text-on-bar`...) y las animaciones.
3. Instala las dependencias: ninguna extra.
4. Fuente: Inter (`next/font/google`) en el contenedor de la página.

## Secciones

- **Modelos por tipo**: Una sección por tipo: número, título, franja con la máquina, «Ver toda la categoría» y las tarjetas de cada modelo.
  Uso: `<ModelosMarca marca={marca} detalle />`
