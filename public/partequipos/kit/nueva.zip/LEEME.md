# Partequipos: Maquinaria pesada nueva

Componentes de Partequipos para Next.js (App Router) + React + Tailwind CSS v4.

## Cómo usarlo

1. Copia `src/components/partequipos/` y `public/partequipos/` a tu proyecto
   con las mismas rutas (el código busca las imágenes en `/partequipos/...`).
2. Pega `estilos/partequipos.css` en tu CSS global, debajo de
   `@import "tailwindcss"`: trae los tokens de color (`bg-brand`,
   `text-on-bar`...) y las animaciones.
3. Instala las dependencias: ninguna extra.
4. Fuente: Inter (`next/font/google`) en el contenedor de la página.

## Secciones

- **Maquinaria pesada nueva**: Rótulo y título con «nueva» en rojo sobre la foto de obra con la retroexcavadora Case Utility Plus de fondo; 5 tarjetas en fila con panel del color de la marca (logo, franja de luz y máquina sobre montañas) y botón; «Ver todo» al final.
  Uso: `<MaquinariaNueva />`
